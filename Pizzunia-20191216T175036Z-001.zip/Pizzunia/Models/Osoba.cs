﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Osoba
    {
        public Osoba()
        {
            Zamówienie = new HashSet<Zamówienie>();
        }

        public int IdOsoba { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }

        public virtual Klient Klient { get; set; }
        public virtual OsobaZalogowana OsobaZalogowana { get; set; }
        public virtual ICollection<Zamówienie> Zamówienie { get; set; }
    }
}
