﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class SkladnikNaPizzy
    {
        public int IdSkladnikNaPizzy { get; set; }
        public int IdSkladnik { get; set; }
        public int IdPizza { get; set; }

        public virtual Pizza IdPizzaNavigation { get; set; }
        public virtual Składnik IdSkladnikNavigation { get; set; }
    }
}
