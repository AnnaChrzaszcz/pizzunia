﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Administrator
    {
        public int IdAdministrator { get; set; }

        public virtual OsobaZalogowana IdAdministratorNavigation { get; set; }
    }
}
