﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Zamówienie
    {
        public Zamówienie()
        {
            PozycjaZamowienia = new HashSet<PozycjaZamowienia>();
        }

        public int IdZamówienie { get; set; }
        public DateTime DataZamowienia { get; set; }
        public DateTime DataDostarczenia { get; set; }
        public int IdOsoba { get; set; }
        public string AdresDostawy { get; set; }
        public int IdStan { get; set; }

        public virtual Osoba IdOsobaNavigation { get; set; }
        public virtual Stan IdStanNavigation { get; set; }
        public virtual ICollection<PozycjaZamowienia> PozycjaZamowienia { get; set; }
    }
}
