﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class KlientZalogowany
    {
        public int IdKlientZalogowany { get; set; }

        public virtual OsobaZalogowana IdKlientZalogowanyNavigation { get; set; }
    }
}
