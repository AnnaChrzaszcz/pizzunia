﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PromotionsController : ControllerBase
    {
        private s16782Context _context;
        public PromotionsController(s16782Context contex)
        {
            _context = contex;
        }

        [HttpGet]
        public IActionResult GetPromotions()
        {
            return Ok(_context.Promocja.ToList());
        }

        [HttpGet("{id:int}")]
        public IActionResult GetPizza(int id)
        {
            var promotion = _context.Promocja.FirstOrDefault(p => p.IdPromocja == id);
            if (promotion == null)
            {
                return NotFound();
            }
            return Ok(promotion);
        }
    }
}