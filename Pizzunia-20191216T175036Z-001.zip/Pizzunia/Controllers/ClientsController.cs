﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientsController : ControllerBase
    {
        private s16782Context _contex;

        public ClientsController(s16782Context context)
        {
            _contex = context;
        }

        [HttpGet]
        public IActionResult GetClients()
        {
            return Ok(_contex.KlientZalogowany.ToList());
        }

        [HttpGet("{id:int}")]
        public IActionResult GetClient(int id)
        {
            var client = _contex.KlientZalogowany.FirstOrDefault(c => c.IdKlientZalogowany == id);
            if(client == null)
            {
                return NotFound();
            }
            return Ok(client);
        }
    }
}