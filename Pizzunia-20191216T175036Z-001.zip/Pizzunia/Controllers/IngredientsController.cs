﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IngredientsController : ControllerBase
    {
        private s16782Context _contex;

        public IngredientsController(s16782Context contex)
        {
            _contex = contex;
        }

        [HttpGet]
        public IActionResult GetIngredients()
        {
            return Ok(_contex.Składnik.ToList());
        }

        [HttpGet("{id:int}")]
        public IActionResult GetIngredient(int id)
        {
            var ingredient= _contex.Składnik.FirstOrDefault(c => c.IdSkladnik == id);
            if (ingredient == null)
            {
                return NotFound();
            }
            return Ok(ingredient);
        }
    }
}