﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class OsobaZalogowana
    {
        public int IdOsobaZalogowana { get; set; }
        public string Haslo { get; set; }
        public string Email { get; set; }
        public string Adres { get; set; }

        public virtual Osoba IdOsobaZalogowanaNavigation { get; set; }
        public virtual Administrator Administrator { get; set; }
        public virtual KlientZalogowany KlientZalogowany { get; set; }
        public virtual Pracownik Pracownik { get; set; }
    }
}
