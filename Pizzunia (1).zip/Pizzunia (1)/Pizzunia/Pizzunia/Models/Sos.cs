﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Sos
    {
        public Sos()
        {
            PozycjaPromocji = new HashSet<PozycjaPromocji>();
            PozycjaZamowienia = new HashSet<PozycjaZamowienia>();
        }

        public int IdSos { get; set; }
        public string Nazwa { get; set; }
        public int Cena { get; set; }

        public virtual ICollection<PozycjaPromocji> PozycjaPromocji { get; set; }
        public virtual ICollection<PozycjaZamowienia> PozycjaZamowienia { get; set; }
    }
}
