﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Pracownik
    {
        public int IdPracownik { get; set; }
        public int Znizka { get; set; }

        public virtual OsobaZalogowana IdPracownikNavigation { get; set; }
    }
}
