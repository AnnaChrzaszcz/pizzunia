﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Pizza
    {
        public Pizza()
        {
            PozycjaPromocji = new HashSet<PozycjaPromocji>();
            PozycjaZamowienia = new HashSet<PozycjaZamowienia>();
            SkladnikNaPizzy = new HashSet<SkladnikNaPizzy>();
        }

        public int IdPizza { get; set; }
        public string Nazwa { get; set; }
        public string Opis { get; set; }

        public virtual ICollection<PozycjaPromocji> PozycjaPromocji { get; set; }
        public virtual ICollection<PozycjaZamowienia> PozycjaZamowienia { get; set; }
        public virtual ICollection<SkladnikNaPizzy> SkladnikNaPizzy { get; set; }
    }
}
