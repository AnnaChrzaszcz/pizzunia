﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Klient
    {
        public int IdKlient { get; set; }
        public int Column2 { get; set; }

        public virtual Osoba IdKlientNavigation { get; set; }
    }
}
