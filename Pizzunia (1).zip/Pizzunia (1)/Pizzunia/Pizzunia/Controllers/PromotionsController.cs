﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PromotionsController : ControllerBase
    {
        private s16782Context _context;
        public PromotionsController(s16782Context contex)
        {
            _context = contex;
        }

        [HttpGet]
        public IActionResult GetPromotions()
        {
            return Ok(_context.Promocja.ToList());
        }

        [HttpGet("{promotionId:int}")]
        public IActionResult GetPromotion(int promotionId)
        {
            var promotion = _context.Promocja.FirstOrDefault(p => p.IdPromocja == promotionId);
            if (promotion == null)
            {
                return NotFound();
            }
            return Ok(promotion);
        }

        [HttpPost]
        public IActionResult CreatePromotion(Promocja promotion)
        {
            _context.Promocja.Add(promotion);
            _context.SaveChanges();

            return StatusCode(201, promotion);
        }

        [HttpPut("{promotionId:int}")]
        public IActionResult Update(int promotionId, Promocja updatedPromotion)
        {
            var promotion = _context.Promocja.FirstOrDefault(e => e.IdPromocja == updatedPromotion.IdPromocja);
            if (promotion == null)
            {
                return NotFound();
            }

            _context.Promocja.Attach(updatedPromotion);
            _context.Entry(updatedPromotion).State = EntityState.Modified;
            _context.SaveChanges();

            return Ok(updatedPromotion);
        }

        [HttpDelete("{promotionId:int}")]
        public IActionResult Delete(int promotionId)
        {
            var promotion = _context.Promocja.FirstOrDefault(e => e.IdPromocja == promotionId);
            if (promotion == null)
            {
                return NotFound();
            }
            _context.Promocja.Remove(promotion);
            _context.SaveChanges();

            return Ok(promotion);
        }
    }
}