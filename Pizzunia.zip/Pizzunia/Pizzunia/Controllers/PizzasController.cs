﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PizzasController : ControllerBase
    {
        private s16782Context _context;
        public PizzasController(s16782Context contex)
        {
            _context = contex;
        }

        [HttpGet]
        public IActionResult GetPizzas()
        {
            return Ok(_context.Pizza.ToList());
        }

        [HttpGet("{id:int}")]
        public IActionResult GetPizza(int id)
        {
            var pizza = _context.Pizza.FirstOrDefault(p => p.IdPizza == id);
            if(pizza == null)
            {
                return NotFound();
            }
            return Ok(pizza);
        }

        [HttpPost]
        public IActionResult CreatePizza(Pizza pizza)
        {
            _context.Pizza.Add(pizza);
            _context.SaveChanges();

            return StatusCode(201, pizza);
        }

        [HttpPut("{pizzatId:int}")]
        public IActionResult Update(int pizzaId, Pizza updatedPizza)
        {
            var pizza = _context.Pizza.FirstOrDefault(e => e.IdPizza == updatedPizza.IdPizza);
            if (pizza == null)
            {
                return NotFound();
            }

            _context.Pizza.Attach(updatedPizza);
            _context.Entry(updatedPizza).State = EntityState.Modified;
            _context.SaveChanges();

            return Ok(updatedPizza);
        }

        [HttpDelete("{pizzaId:int}")]
        public IActionResult Delete(int pizzaId)
        {
            var pizza = _context.Pizza.FirstOrDefault(e => e.IdPizza == pizzaId);
            if (pizza == null)
            {
                return NotFound();
            }
            _context.Pizza.Remove(pizza);
            _context.SaveChanges();

            return Ok(pizza);
        }
    }
}