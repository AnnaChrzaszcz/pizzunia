﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IngredientsController : ControllerBase
    {
        private s16782Context _context;

        public IngredientsController(s16782Context context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetIngredients()
        {
            return Ok(_context.Składnik.ToList());
        }

        [HttpGet("{id:int}")]
        public IActionResult GetIngredient(int id)
        {
            var ingredient= _context.Składnik.FirstOrDefault(c => c.IdSkladnik == id);
            if (ingredient == null)
            {
                return NotFound();
            }
            return Ok(ingredient);
        }

        [HttpPost]
        public IActionResult CreateIngredient(Składnik ingredient)
        {
            _context.Składnik.Add(ingredient);
            _context.SaveChanges();

            return StatusCode(201, ingredient);
        }

        [HttpPut("{ingredientId:int}")]
        public IActionResult Update(int ingredientId, Składnik updatedIngredient)
        {
            var ingredient = _context.Składnik.FirstOrDefault(e => e.IdSkladnik == updatedIngredient.IdSkladnik);
            if (ingredient == null)
            {
                return NotFound();
            }

            _context.Składnik.Attach(updatedIngredient);
            _context.Entry(updatedIngredient).State = EntityState.Modified;
            _context.SaveChanges();

            return Ok(updatedIngredient);
        }

        [HttpDelete("{ingredientId:int}")]
        public IActionResult Delete(int ingredientId)
        {
            var ingredient = _context.Składnik.FirstOrDefault(e => e.IdSkladnik == ingredientId);
            if (ingredient == null)
            {
                return NotFound();
            }
            _context.Składnik.Remove(ingredient);
            _context.SaveChanges();

            return Ok(ingredient);
        }
  







}
}