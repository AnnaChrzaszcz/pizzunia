﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pizzunia.Models;

namespace Pizzunia.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientsController : ControllerBase
    {
        private s16782Context _context;

        public ClientsController(s16782Context context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetClients()
        {
            return Ok(_context.KlientZalogowany.ToList());
        }

        [HttpGet("{id:int}")]
        public IActionResult GetClient(int id)
        {
            var client = _context.KlientZalogowany.FirstOrDefault(c => c.IdKlientZalogowany == id);
            if(client == null)
            {
                return NotFound();
            }
            return Ok(client);
        }

        [HttpPost]
        public IActionResult CreateClient(KlientZalogowany newClient)
        {
            _context.KlientZalogowany.Add(newClient);
            _context.SaveChanges();

            return StatusCode(201, newClient);
        }

        [HttpPut("{clientId:int}")]
        public IActionResult Update(int clientId ,KlientZalogowany updatedClient)
        {
            var client = _context.KlientZalogowany.FirstOrDefault(e => e.IdKlientZalogowany == updatedClient.IdKlientZalogowany);
            if(client == null)
            {
                return NotFound();
            }

            _context.KlientZalogowany.Attach(updatedClient);
            _context.Entry(updatedClient).State = EntityState.Modified;
            _context.SaveChanges();

            return Ok(updatedClient);
        }

        [HttpDelete("{clientID:int}")]
        public IActionResult Delete(int clientId)
        {
            var client = _context.KlientZalogowany.FirstOrDefault(e => e.IdKlientZalogowany == clientId);
            if(client == null)
            {
                return NotFound();
            }
            _context.KlientZalogowany.Remove(client);
            _context.SaveChanges();

            return Ok(client);
        }
    }
}