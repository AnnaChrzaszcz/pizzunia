﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Pizzunia.Models
{
    public partial class s16782Context : DbContext
    {
        public s16782Context()
        {
        }

        public s16782Context(DbContextOptions<s16782Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Administrator> Administrator { get; set; }
        public virtual DbSet<Klient> Klient { get; set; }
        public virtual DbSet<KlientZalogowany> KlientZalogowany { get; set; }
        public virtual DbSet<Osoba> Osoba { get; set; }
        public virtual DbSet<OsobaZalogowana> OsobaZalogowana { get; set; }
        public virtual DbSet<Pizza> Pizza { get; set; }
        public virtual DbSet<PozycjaPromocji> PozycjaPromocji { get; set; }
        public virtual DbSet<PozycjaZamowienia> PozycjaZamowienia { get; set; }
        public virtual DbSet<Pracownik> Pracownik { get; set; }
        public virtual DbSet<Promocja> Promocja { get; set; }
        public virtual DbSet<SkladnikNaPizzy> SkladnikNaPizzy { get; set; }
        public virtual DbSet<Składnik> Składnik { get; set; }
        public virtual DbSet<Sos> Sos { get; set; }
        public virtual DbSet<Stan> Stan { get; set; }
        public virtual DbSet<Zamówienie> Zamówienie { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=db-mssql;Initial Catalog=s16782;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Administrator>(entity =>
            {
                entity.HasKey(e => e.IdAdministrator)
                    .HasName("Administrator_pk");

                entity.Property(e => e.IdAdministrator).ValueGeneratedNever();

                entity.HasOne(d => d.IdAdministratorNavigation)
                    .WithOne(p => p.Administrator)
                    .HasForeignKey<Administrator>(d => d.IdAdministrator)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Administrator_OsobaZalogowana");
            });

            modelBuilder.Entity<Klient>(entity =>
            {
                entity.HasKey(e => e.IdKlient)
                    .HasName("Klient_pk");

                entity.Property(e => e.IdKlient).ValueGeneratedNever();

                entity.Property(e => e.Column2).HasColumnName("column_2");

                entity.HasOne(d => d.IdKlientNavigation)
                    .WithOne(p => p.Klient)
                    .HasForeignKey<Klient>(d => d.IdKlient)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Klient_Osoba");
            });

            modelBuilder.Entity<KlientZalogowany>(entity =>
            {
                entity.HasKey(e => e.IdKlientZalogowany)
                    .HasName("KlientZalogowany_pk");

                entity.Property(e => e.IdKlientZalogowany).ValueGeneratedNever();

                entity.HasOne(d => d.IdKlientZalogowanyNavigation)
                    .WithOne(p => p.KlientZalogowany)
                    .HasForeignKey<KlientZalogowany>(d => d.IdKlientZalogowany)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("KlientZalogowany_OsobaZalogowana");
            });

            modelBuilder.Entity<Osoba>(entity =>
            {
                entity.HasKey(e => e.IdOsoba)
                    .HasName("Osoba_pk");

                entity.Property(e => e.IdOsoba).ValueGeneratedNever();

                entity.Property(e => e.Imie)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Nazwisko)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<OsobaZalogowana>(entity =>
            {
                entity.HasKey(e => e.IdOsobaZalogowana)
                    .HasName("OsobaZalogowana_pk");

                entity.Property(e => e.IdOsobaZalogowana).ValueGeneratedNever();

                entity.Property(e => e.Adres)
                    .IsRequired()
                    .HasColumnName("adres")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Haslo)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdOsobaZalogowanaNavigation)
                    .WithOne(p => p.OsobaZalogowana)
                    .HasForeignKey<OsobaZalogowana>(d => d.IdOsobaZalogowana)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("OsobaZalogowana_Osoba");
            });

            modelBuilder.Entity<Pizza>(entity =>
            {
                entity.HasKey(e => e.IdPizza)
                    .HasName("Pizza_pk");

                entity.Property(e => e.IdPizza).ValueGeneratedNever();

                entity.Property(e => e.Nazwa)
                    .IsRequired()
                    .HasColumnName("nazwa")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Opis)
                    .IsRequired()
                    .HasColumnName("opis")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PozycjaPromocji>(entity =>
            {
                entity.HasKey(e => e.IdPozycjaPromocji)
                    .HasName("PozycjaPromocji_pk");

                entity.Property(e => e.IdPozycjaPromocji).ValueGeneratedNever();

                entity.HasOne(d => d.IdPizzaNavigation)
                    .WithMany(p => p.PozycjaPromocji)
                    .HasForeignKey(d => d.IdPizza)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PozycjaPromocji_Pizza");

                entity.HasOne(d => d.IdPromocjaNavigation)
                    .WithMany(p => p.PozycjaPromocji)
                    .HasForeignKey(d => d.IdPromocja)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PozycjaPromocji_Promocja");

                entity.HasOne(d => d.IdSosNavigation)
                    .WithMany(p => p.PozycjaPromocji)
                    .HasForeignKey(d => d.IdSos)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PozycjaPromocji_Sos");
            });

            modelBuilder.Entity<PozycjaZamowienia>(entity =>
            {
                entity.HasKey(e => e.IdPozycjaZamówienia)
                    .HasName("PozycjaZamowienia_pk");

                entity.Property(e => e.IdPozycjaZamówienia).ValueGeneratedNever();

                entity.Property(e => e.Rozmiar).HasColumnName("rozmiar");

                entity.HasOne(d => d.IdPizzaNavigation)
                    .WithMany(p => p.PozycjaZamowienia)
                    .HasForeignKey(d => d.IdPizza)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PozycjaZamówienia_Pizza");

                entity.HasOne(d => d.IdSosNavigation)
                    .WithMany(p => p.PozycjaZamowienia)
                    .HasForeignKey(d => d.IdSos)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PozycjaZamowienia_Sos");

                entity.HasOne(d => d.IdZamówienieNavigation)
                    .WithMany(p => p.PozycjaZamowienia)
                    .HasForeignKey(d => d.IdZamówienie)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("PozycjaZamówienia_Zamówienie");
            });

            modelBuilder.Entity<Pracownik>(entity =>
            {
                entity.HasKey(e => e.IdPracownik)
                    .HasName("Pracownik_pk");

                entity.Property(e => e.IdPracownik).ValueGeneratedNever();

                entity.Property(e => e.Znizka).HasColumnName("znizka");

                entity.HasOne(d => d.IdPracownikNavigation)
                    .WithOne(p => p.Pracownik)
                    .HasForeignKey<Pracownik>(d => d.IdPracownik)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Pracownik_OsobaZalogowana");
            });

            modelBuilder.Entity<Promocja>(entity =>
            {
                entity.HasKey(e => e.IdPromocja)
                    .HasName("Promocja_pk");

                entity.Property(e => e.IdPromocja).ValueGeneratedNever();

                entity.Property(e => e.Cena).HasColumnName("cena");

                entity.Property(e => e.Opis)
                    .IsRequired()
                    .HasColumnName("opis")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SkladnikNaPizzy>(entity =>
            {
                entity.HasKey(e => e.IdSkladnikNaPizzy)
                    .HasName("SkladnikNaPizzy_pk");

                entity.Property(e => e.IdSkladnikNaPizzy).ValueGeneratedNever();

                entity.HasOne(d => d.IdPizzaNavigation)
                    .WithMany(p => p.SkladnikNaPizzy)
                    .HasForeignKey(d => d.IdPizza)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("SkladnikNaPizzy_Pizza");

                entity.HasOne(d => d.IdSkladnikNavigation)
                    .WithMany(p => p.SkladnikNaPizzy)
                    .HasForeignKey(d => d.IdSkladnik)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("SkladnikNaPizzy_Składnik");
            });

            modelBuilder.Entity<Składnik>(entity =>
            {
                entity.HasKey(e => e.IdSkladnik)
                    .HasName("Składnik_pk");

                entity.Property(e => e.IdSkladnik).ValueGeneratedNever();

                entity.Property(e => e.Nazwa)
                    .IsRequired()
                    .HasColumnName("nazwa")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Sos>(entity =>
            {
                entity.HasKey(e => e.IdSos)
                    .HasName("Sos_pk");

                entity.Property(e => e.IdSos).ValueGeneratedNever();

                entity.Property(e => e.Cena).HasColumnName("cena");

                entity.Property(e => e.Nazwa)
                    .IsRequired()
                    .HasColumnName("nazwa")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Stan>(entity =>
            {
                entity.HasKey(e => e.IdStan)
                    .HasName("Stan_pk");

                entity.Property(e => e.IdStan).ValueGeneratedNever();

                entity.Property(e => e.Opis).HasColumnName("opis");
            });

            modelBuilder.Entity<Zamówienie>(entity =>
            {
                entity.HasKey(e => e.IdZamówienie)
                    .HasName("Zamówienie_pk");

                entity.Property(e => e.IdZamówienie).ValueGeneratedNever();

                entity.Property(e => e.AdresDostawy)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DataDostarczenia).HasColumnType("date");

                entity.Property(e => e.DataZamowienia).HasColumnType("date");

                entity.HasOne(d => d.IdOsobaNavigation)
                    .WithMany(p => p.Zamówienie)
                    .HasForeignKey(d => d.IdOsoba)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Zamówienie_Osoba");

                entity.HasOne(d => d.IdStanNavigation)
                    .WithMany(p => p.Zamówienie)
                    .HasForeignKey(d => d.IdStan)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("Zamówienie_Stan");
            });
        }
    }
}
