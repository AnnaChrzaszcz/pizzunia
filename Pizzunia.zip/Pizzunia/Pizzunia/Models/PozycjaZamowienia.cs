﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class PozycjaZamowienia
    {
        public int IdPozycjaZamówienia { get; set; }
        public int IdPizza { get; set; }
        public int PizzaIlosc { get; set; }
        public int Rozmiar { get; set; }
        public int IdZamówienie { get; set; }
        public int IdSos { get; set; }
        public int SosIlosc { get; set; }

        public virtual Pizza IdPizzaNavigation { get; set; }
        public virtual Sos IdSosNavigation { get; set; }
        public virtual Zamówienie IdZamówienieNavigation { get; set; }
    }
}
