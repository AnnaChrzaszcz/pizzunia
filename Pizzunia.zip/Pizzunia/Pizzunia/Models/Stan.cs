﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Stan
    {
        public Stan()
        {
            Zamówienie = new HashSet<Zamówienie>();
        }

        public int IdStan { get; set; }
        public int Opis { get; set; }

        public virtual ICollection<Zamówienie> Zamówienie { get; set; }
    }
}
