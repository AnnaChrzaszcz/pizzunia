﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Składnik
    {
        public Składnik()
        {
            SkladnikNaPizzy = new HashSet<SkladnikNaPizzy>();
        }

        public int IdSkladnik { get; set; }
        public string Nazwa { get; set; }

        public virtual ICollection<SkladnikNaPizzy> SkladnikNaPizzy { get; set; }
    }
}
