﻿using System;
using System.Collections.Generic;

namespace Pizzunia.Models
{
    public partial class Promocja
    {
        public Promocja()
        {
            PozycjaPromocji = new HashSet<PozycjaPromocji>();
        }

        public int IdPromocja { get; set; }
        public int Cena { get; set; }
        public string Opis { get; set; }

        public virtual ICollection<PozycjaPromocji> PozycjaPromocji { get; set; }
    }
}
